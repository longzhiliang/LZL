function s=isempty(t)
s=isempty(t.matrix);