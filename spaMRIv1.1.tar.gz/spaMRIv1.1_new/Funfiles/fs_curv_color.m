function Cdata = fs_curv_color(vertices,v_curv)
% This function is to obtain RGB color Cdata for ?h.curv
% vertices     -  surface vertices
% v_curv       -  ?h.curv value
% colorpath    -  path-to-colormap
% Author, Zhiliang Long, 2017-9-13
%%

h1                           = repmat([0.7 0.7 0.7],11,1);
h2                           = repmat([0.5 0.5 0.5],9,1);
colorname                    = [h1;h2];
clear h1 h2

Cdata                        = zeros(length(vertices),3);
A                            = (v_curv - min(v_curv))./(max(v_curv) - min(v_curv));
A                            = ceil(A*size(colorname,1));
A(A>size(colorname,1))       = size(colorname,1);
for i=1:size(colorname,1)
    Cdata(find(A == i),:)    = repmat(colorname(i,:),length(find(A==i)),1);
end
clear A B
end