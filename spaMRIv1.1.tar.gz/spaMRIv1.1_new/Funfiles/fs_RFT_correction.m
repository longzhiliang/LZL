function pval = fs_RFT_correction(surfdata,type,hemi,mask,designmatrix,contrast,pth,pcorrect,sides,outdir)
% Random field theory correction for surface-based statistics
% Useage: fs_RFT_correction(surfdata,type,hemi,mask,designmatrix,contrast,pth,pcorrect,sides,outdir)
%
% Input:
%    surfdata     -  n x v surface data matrix, n is #of subjects, v is #of vertices
%    type         - vertex-wise or cluster-wise
%    hemi         - lh or rh
%    mask         - 1 x v binary data matrix.  
%    designmatrix - design matrix n x p
%    contrast     - m x p contrast
%    pth          - vertex level p threshold
%    pcorrect     - corrected P
%    sides        - One-tail or Two-tail
%    outdir       - a folder used for saving some files
% Output:
%    pval         - 1 x v vector with 1 indicating those vertex/clusters survived RFT correction, 0 otherwise.
%
% Author: Zhiliang Long
%%
global FREESURFER_HOME

[vertices, faces]     = freesurfer_read_surf([FREESURFER_HOME,filesep,'subjects',filesep,'fsaverage',filesep,'surf',filesep,[hemi,'.white']]);
avgsurf.tri           = faces;
avgsurf.coord         = vertices';
clear vertices faces
switch sides
    case 'Two-tail'
        pcorrect      = pcorrect/2;
        pth             = pth/2;
    case 'One-tail'
        pcorrect      = pcorrect;
        pth             = pth;
end
    
if size(contrast,1) == 1
    fprintf('performing randome field theory correction on T-statistic ...\n');
    slm                   = StatLinMod(surfdata,term(designmatrix),avgsurf);
    slm.k                 = 1;
    mask                  = mask~=0;
    slmRightSide          = StatT(slm,designmatrix*contrast');
    slmLeftSide           = StatT(slm,designmatrix*(-1)*contrast');
    [pvalPos,~,clusPos]   = StatP(slmRightSide,mask,pth); 
    [pvalNeg,~,clusNeg]   = StatP(slmLeftSide,mask,pth);
    pvalPos.P(~mask)      = 1;
    pvalPos.C(~mask)      = 1;
    pvalNeg.P(~mask)      = 1;
    pvalNeg.C(~mask)      = 1;
 
    if strcmp(type,'vertex-wise')
        pvalPos           = double(pvalPos.P < pcorrect);
        pvalNeg           = double(pvalNeg.P < pcorrect);
        pval              = pvalPos + pvalNeg;
    elseif strcmp(type,'cluster-wise')
        if ~isempty(clusPos)
            pvalPos       = double(pvalPos.C < pcorrect);
        else
            pvalPos       = zeros(1,size(surfdata,2));
        end
        if ~isempty(clusNeg)
            pvalNeg       = double(pvalNeg.C < pcorrect);
        else
            pvalNeg       = zeros(1,size(surfdata,2));
        end
        pval              = pvalPos + pvalNeg;
    end
    clear slm pvalPos pvalNeg clusPos clusNeg slmRightSide slmLeftSide
elseif size(contrast,1) > 1
    fprintf('performing randome field theory correction on F-statistic ...\n');
    % re-organize the design and contrast
    VarNoInterest         = find(sum(abs(contrast),1) == 0);
    VarInterest           = find(sum(abs(contrast),1) ~= 0);
    designmatrix          = [designmatrix(:,VarInterest) designmatrix(:,VarNoInterest)];
    contrast              = [contrast(:,VarInterest) contrast(:,VarNoInterest)];
    slm1                  = StatLinMod(surfdata,term(designmatrix),avgsurf); % estimate the GLM
    % calculate reduced design matrix
    ReducedCon1           = pinv([1 zeros(1,size(contrast,2)-1);contrast])*[1;zeros(size(contrast,1),1)];
    ReducedCon2           = zeros(size(contrast,1),length(VarNoInterest));
    for i=1:size(ReducedCon2,2)
        ReducedCon2(length(VarInterest)+i,i) = 1;
    end
    if ~isempty(ReducedCon2)
        ReducedDesign     = designmatrix*[ReducedCon1 ReducedCon2];
    else
        ReducedDesign     = designmatrix*ReducedCon1;
    end
    slm2                  = StatLinMod(surfdata,term(ReducedDesign),avgsurf); % estimate the reduced GLM
    
    % save the reduced design matrix
    fid                   = fopen([fileparts(fullfile(outdir)),filesep,'rftF_reduced_design.txt'],'a+'); 
    for i=1:size(ReducedDesign,1)
        fprintf(fid,'%f\n',ReducedDesign(i,:)); 
    end
    fclose(fid);
    fid                   = fopen([fileparts(fullfile(outdir)),filesep,'rftF_contrast.txt'],'a+'); 
    for i=1:size(ReducedCon1,1)
        if ~isempty(ReducedCon2)
            fprintf(fid,'%f\n',[ReducedCon1(i,:) ReducedCon2(i,:)]);
        else
            fprintf(fid,'%f\n',ReducedCon1(i,:));
        end
    end
    fclose(fid);
    clear i
    
    % comparing slm1 and slm2
    slm                   = StatF( slm1, slm2 );
    slm.k                 = 1;
    mask                  = mask~=0;
    [pval,~,clus]         = StatP(slm,mask,pth);
    pval.P(~mask)         = 1;
    pval.C(~mask)         = 1;
    if strcmp(type,'vertex-wise')
        pval              = double(pval.P < pcorrect);
    elseif strcmp(type,'cluster-wise')
        if ~isempty(clus)
            pval          = double(pval.C < pcorrect);
        else
            pval          = zeros(1,size(surfdata,2));
        end
    end
    clear VarNoInterest VarInterest slm1 slm2 slm clus ReducedDesign ReducedCon1 ReducedCon2
end
end