function OutF = fs_rescale(InputF)
%% fs_rescale - cut out edges of an image.
%   InputF      - input image, 2-dimentional images
%   OutF        - output image
%%
[M,N]   = size(InputF);
CutInd  = [];
for i=1:M
    if length(unique(InputF(i,:))) == 1
        CutInd = [CutInd;i];
    end
end
InputF(CutInd,:) = [];

CutInd = [];
for i=1:N
    if length(unique(InputF(:,i))) == 1
        CutInd = [CutInd;i];
    end
end
InputF(:,CutInd) = [];

OutF = InputF;
end