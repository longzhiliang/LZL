function varargout = fs_rftsetup(varargin)
% FS_RFTSETUP MATLAB code for fs_rftsetup.fig
%      FS_RFTSETUP, by itself, creates a new FS_RFTSETUP or raises the existing
%      singleton*.
%
%      H = FS_RFTSETUP returns the handle to a new FS_RFTSETUP or the handle to
%      the existing singleton*.
%
%      FS_RFTSETUP('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FS_RFTSETUP.M with the given input arguments.
%
%      FS_RFTSETUP('Property','Value',...) creates a new FS_RFTSETUP or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before fs_rftsetup_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to fs_rftsetup_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help fs_rftsetup

% Last Modified by GUIDE v2.5 25-Jun-2018 11:49:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @fs_rftsetup_OpeningFcn, ...
                   'gui_OutputFcn',  @fs_rftsetup_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before fs_rftsetup is made visible.
function fs_rftsetup_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to fs_rftsetup (see VARARGIN)

% Choose default command line output for fs_rftsetup
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


% UIWAIT makes fs_rftsetup wait for user response (see UIRESUME)
% uiwait(handles.figure1);
rftpara           = getappdata(0,'rftpara');
if strcmp(rftpara.type,'vertex-wise')
    set(handles.pushbutton8,'Enable','off');
    set(handles.edit7,'Enable','off');
elseif strcmp(rftpara.type,'cluster-wise')
    set(handles.pushbutton8,'Enable','on');
    set(handles.edit7,'Enable','on');
end


% --- Outputs from this function are returned to the command line.
function varargout = fs_rftsetup_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
vol_path                = char(getappdata(0,'vol_path')); % overlay volume path
vol_dir                 = fileparts(fullfile(vol_path));
vol_dir                 = fileparts(fullfile(vol_dir));
if exist([vol_dir,filesep,'MergeData.mgh'],'file')
    set(hObject,'string',[vol_dir,filesep,'MergeData.mgh']);
else
    set(hObject,'string','');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
vol_path                = char(getappdata(0,'vol_path')); % overlay volume path
vol_dir                 = fileparts(fullfile(vol_path));
vol_dir                 = fileparts(fullfile(vol_dir));
if exist([vol_dir,filesep,'Xg.dat'],'file')
    set(hObject,'string',[vol_dir,filesep,'Xg.dat']);
else
    set(hObject,'string','');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
vol_path                = char(getappdata(0,'vol_path')); % overlay volume path
vol_dir                 = fileparts(fullfile(vol_path));
if exist([vol_dir,filesep,'C.dat'],'file')
    set(hObject,'string',[vol_dir,filesep,'C.dat']);
else
    set(hObject,'string','');
end



% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename,filepath]              = uigetfile('*.mgh','Select the merged surface file');
if ischar(filename)
    set(handles.edit3,'string',fullfile([filepath,filesep,filename]));
end
clear filename filepath

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename,filepath]              = uigetfile('*.dat','Select the design matrix (Xg.dat)');
if ischar(filename)
    set(handles.edit4,'string',fullfile([filepath,filesep,filename]));
end
clear filename filepath

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename,filepath]              = uigetfile('*.dat','Select the contrast matrix (C.dat)');
if ischar(filename)
    set(handles.edit5,'string',fullfile([filepath,filesep,filename]));
end
clear filename filepath

% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
rftpara                    = getappdata(0,'rftpara');
rftpara.pthresh            = str2double(get(handles.edit7,'string'));
rftpara.pcorrect           = str2double(get(handles.edit2,'string'));
sign                       = get(handles.popupmenu1,'string');
rftpara.sign               = sign{get(handles.popupmenu1,'value')}; clear sign
rftpara.data               = get(handles.edit3,'string');
rftpara.design             = get(handles.edit4,'string');
rftpara.contrast           = get(handles.edit5,'string');
setappdata(0,'rftpara',  rftpara); % parameters for RFT correction
close(gcf);
fprintf('Parameters for RFT correction:\n');
fprintf('  pthresh : %f:\n',rftpara.pthresh);
fprintf('  pcorrect : %f:\n',rftpara.pcorrect);
fprintf('  rft-type: %s\n',rftpara.type);
fprintf('  sign : %s:\n',rftpara.sign);
fprintf('  data : %s\n',rftpara.data);
if ~isempty(rftpara.data)
  data                     = load_mgh(rftpara.data);
  fprintf('  data(size) : %s\n',num2str(size(data))); clear data
end
fprintf('  design : %s:\n',rftpara.design);
if ~isempty(rftpara.design)
  data                     = load(rftpara.design);
  fprintf('  design(size) : %s\n',num2str(size(data))); clear data
end
fprintf('  contrast : %s\n',rftpara.contrast);
if ~isempty(rftpara.contrast)
  data                     = load(rftpara.contrast);
  if size(data,1) > 1 && size(data,2) > 1
      fprintf('Perfrom rft on F-statistic\n');
  end
  fprintf('  contrast(size) : %s\n',num2str(size(data))); clear data
end

% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
